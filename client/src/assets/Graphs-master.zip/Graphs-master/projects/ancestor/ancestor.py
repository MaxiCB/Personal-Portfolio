
def earliest_ancestor(ancestors, starting_node):
    pass